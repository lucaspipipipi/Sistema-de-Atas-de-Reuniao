package com.exemplo.sistema_atas.Model;

import jakarta.persistence.*;

@Entity
public class ParticipanteExterno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String empresa;
    private String email;

    // Construtores
    public ParticipanteExterno() {}

    public ParticipanteExterno(String nome, String empresa, String email) {
        this.nome = nome;
        this.empresa = empresa;
        this.email = email;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmpresa() { return empresa; }
    public void setEmpresa(String empresa) { this.empresa = empresa; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // toString()
    @Override
    public String toString() {
        return "ParticipanteExterno{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", empresa='" + empresa + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
