
package com.exemplo.sistema_atas.Controller;

import com.exemplo.sistema_atas.Model.Ata;
import com.exemplo.sistema_atas.Repository.AtaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/atas")
public class AtaController {
    @Autowired
    private AtaRepository ataRepository;

    @GetMapping
    public List<Ata> listarAtas() {
        return ataRepository.findAll();
    }

    @PostMapping
    public Ata criarAta(@RequestBody Ata ata) {
        return ataRepository.save(ata);
    }

    @GetMapping("/{id}")
    public Optional<Ata> obterAtaPorId(@PathVariable Long id) {
        return ataRepository.findById(id);
    }

    @PutMapping("/{id}")
    public Ata atualizarAta(@PathVariable Long id, @RequestBody Ata ataAtualizada) {
        return ataRepository.findById(id)
                .map(ata -> {
                    ata.setTitulo(ataAtualizada.getTitulo());
                    ata.setDataEmissao(ataAtualizada.getDataEmissao());
                    ata.setInicio(ataAtualizada.getInicio());
                    ata.setTermino(ataAtualizada.getTermino());
                    ata.setPauta(ataAtualizada.getPauta());
                    ata.setDescricao(ataAtualizada.getDescricao());
                    ata.setPalavrasChave(ataAtualizada.getPalavrasChave());
                    ata.setTipo(ataAtualizada.getTipo());
                    ata.setStatus(ataAtualizada.getStatus());
                    return ataRepository.save(ata);
                })
                .orElseGet(() -> {
                    ataAtualizada.setId(id);
                    return ataRepository.save(ataAtualizada);
                });
    }

    @DeleteMapping("/{id}")
    public void deletarAta(@PathVariable Long id) {
        ataRepository.deleteById(id);
    }
}
