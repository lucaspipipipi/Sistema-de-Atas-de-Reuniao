package com.exemplo.sistema_atas.Repository;

import com.exemplo.sistema_atas.Model.Sugestao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SugestaoRepository extends JpaRepository<Sugestao, Long> {
}
