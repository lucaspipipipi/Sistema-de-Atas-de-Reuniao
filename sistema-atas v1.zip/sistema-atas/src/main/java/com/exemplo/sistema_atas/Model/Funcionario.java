package com.exemplo.sistema_atas.Model;

import jakarta.persistence.*;

@Entity
public class Funcionario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String matricula;
    private char sexo; // 'm' ou 'f'
    private String nascimento;
    private String email;

    // Construtores
    public Funcionario() {}

    public Funcionario(String nome, String matricula, char sexo, String nascimento, String email) {
        this.nome = nome;
        this.matricula = matricula;
        this.sexo = sexo;
        this.nascimento = nascimento;
        this.email = email;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getMatricula() { return matricula; }
    public void setMatricula(String matricula) { this.matricula = matricula; }
    public char getSexo() { return sexo; }
    public void setSexo(char sexo) { this.sexo = sexo; }
    public String getNascimento() { return nascimento; }
    public void setNascimento(String nascimento) { this.nascimento = nascimento; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // toString()
    @Override
    public String toString() {
        return "Funcionario{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", matricula='" + matricula + '\'' +
                ", sexo=" + sexo +
                ", nascimento='" + nascimento + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}

