package com.exemplo.sistema_atas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaAtasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaAtasApplication.class, args);
	}

}
