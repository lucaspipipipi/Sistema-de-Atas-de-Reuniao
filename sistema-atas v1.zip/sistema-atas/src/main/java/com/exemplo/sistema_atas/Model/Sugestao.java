package com.exemplo.sistema_atas.Model;

import jakarta.persistence.*;

@Entity
public class Sugestao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String data;

    @Column(length = 500)
    private String descricao;

    // Construtores
    public Sugestao() {}

    public Sugestao(String data, String descricao) {
        this.data = data;
        this.descricao = descricao;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    // toString()
    @Override
    public String toString() {
        return "Sugestao{" +
                "id=" + id +
                ", data='" + data + '\'' +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
