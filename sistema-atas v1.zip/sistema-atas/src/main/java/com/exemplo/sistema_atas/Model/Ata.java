package com.exemplo.sistema_atas.Model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Ata {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;
    private String dataEmissao;
    private String inicio;
    private String termino;
    private String pauta;

    @Column(length = 3000)
    private String descricao;

    @ElementCollection
    private List<String> palavrasChave;

    private String tipo; // "publica" ou "privada"
    private String status; // "Emissão", "Revisão", "Conclusão", "Emitida"

    // Construtores
    public Ata() {}

    public Ata(String titulo, String dataEmissao, String inicio, String termino, String pauta, String descricao, List<String> palavrasChave, String tipo, String status) {
        this.titulo = titulo;
        this.dataEmissao = dataEmissao;
        this.inicio = inicio;
        this.termino = termino;
        this.pauta = pauta;
        this.descricao = descricao;
        this.palavrasChave = palavrasChave;
        this.tipo = tipo;
        this.status = status;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getDataEmissao() { return dataEmissao; }
    public void setDataEmissao(String dataEmissao) { this.dataEmissao = dataEmissao; }
    public String getInicio() { return inicio; }
    public void setInicio(String inicio) { this.inicio = inicio; }
    public String getTermino() { return termino; }
    public void setTermino(String termino) { this.termino = termino; }
    public String getPauta() { return pauta; }
    public void setPauta(String pauta) { this.pauta = pauta; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public List<String> getPalavrasChave() { return palavrasChave; }
    public void setPalavrasChave(List<String> palavrasChave) { this.palavrasChave = palavrasChave; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // toString()
    @Override
    public String toString() {
        return "Ata{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", dataEmissao='" + dataEmissao + '\'' +
                ", inicio='" + inicio + '\'' +
                ", termino='" + termino + '\'' +
                ", pauta='" + pauta + '\'' +
                ", descricao='" + descricao + '\'' +
                ", palavrasChave=" + palavrasChave +
                ", tipo='" + tipo + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
