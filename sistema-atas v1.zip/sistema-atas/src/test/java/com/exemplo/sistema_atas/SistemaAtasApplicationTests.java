package com.exemplo.sistema_atas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaAtasApplicationTests {

	@Test
	void contextLoads() {
	}

}
